package com.bansi.cropdemogrow

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FilterAdapter(
    private var filterList: List<FilterItem>,
    private val onFilterSelected: (Int) -> Unit
) : RecyclerView.Adapter<FilterAdapter.FilterViewHolder>() {

    private var selectedPosition = 0

    inner class FilterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val filterImageView: ImageView = itemView.findViewById(R.id.iv_filter_preview)
        private val filterNameText: TextView = itemView.findViewById(R.id.tv_filter_name)
        private val selectionBorder: View = itemView.findViewById(R.id.view_selection_border)

        fun bind(filterItem: FilterItem, position: Int) {
            filterNameText.text = filterItem.name
            
            // Set preview image
            filterItem.previewBitmap?.let { bitmap ->
                filterImageView.setImageBitmap(bitmap)
            }

            // Show/hide selection border
            selectionBorder.visibility = if (position == selectedPosition) {
                View.VISIBLE
            } else {
                View.GONE
            }

            // Handle click
            itemView.setOnClickListener {
                val previousPosition = selectedPosition
                selectedPosition = position
                notifyItemChanged(previousPosition)
                notifyItemChanged(selectedPosition)
                onFilterSelected(filterItem.id)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilterViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_filter_preview, parent, false)
        return FilterViewHolder(view)
    }

    override fun onBindViewHolder(holder: FilterViewHolder, position: Int) {
        holder.bind(filterList[position], position)
    }

    override fun getItemCount(): Int = filterList.size

    fun updateFilters(newFilterList: List<FilterItem>) {
        filterList = newFilterList
        notifyDataSetChanged()
    }

    fun setSelectedFilter(filterIndex: Int) {
        val previousPosition = selectedPosition
        selectedPosition = filterIndex
        notifyItemChanged(previousPosition)
        notifyItemChanged(selectedPosition)
    }
}