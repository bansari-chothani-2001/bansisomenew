package com.bansi.cropdemogrow

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentationResult
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenter
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlin.math.*

class CustomCropOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var originalBitmap: Bitmap? = null
    private var currentBitmap: Bitmap? = null
    private var displayBitmap: Bitmap? = null

    // ML Kit Subject Segmenter
    private var subjectSegmenter: SubjectSegmenter? = null

    // Cache for processed bitmap to avoid repeated processing
    private var cachedProcessedBitmap: Bitmap? = null
    private var lastRotationAngle = 0f
    private var lastFilterIndex = 0
    private var needsReprocessing = true

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        isFilterBitmap = true
    }
    private val cropPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 13f
    }
    private val overlayPaint = Paint().apply {
        color = Color.parseColor("#80000000")
    }
    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.FILL
    }
    private val cornerStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val edgeHandlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.FILL
    }
    private val edgeHandleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private var imageRect = RectF()
    private var cropRect = RectF()
    private var originalImageRect = RectF() // Store original image bounds for accurate calculation
    private var isCropMode = false
    private var isDragging = false
    private var isResizing = false
    private var dragHandle = -1
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    private var rotationAngle = 0f
    private var filterIndex = 0

    private val cornerRadius = 22f
    private val edgeHandleSize = 18f
    private val touchTolerance = 50f
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val widthMode = MeasureSpec.getMode(widthMeasureSpec)
        val heightMode = MeasureSpec.getMode(heightMeasureSpec)
        val widthSize = MeasureSpec.getSize(widthMeasureSpec)
        val heightSize = MeasureSpec.getSize(heightMeasureSpec)

        val width = when (widthMode) {
            MeasureSpec.EXACTLY -> widthSize
            MeasureSpec.AT_MOST -> widthSize
            else -> 300 // Default minimum width
        }

        val height = when (heightMode) {
            MeasureSpec.EXACTLY -> heightSize
            MeasureSpec.AT_MOST -> heightSize
            else -> 300 // Default minimum height
        }

        setMeasuredDimension(width, height)
    }
    // Handle positions: 0=TL, 1=TR, 2=BL, 3=BR, 4=center, 5=top, 6=right, 7=bottom, 8=left
    private val handles = arrayOf(
        PointF(), PointF(), PointF(), PointF(), PointF(),
        PointF(), PointF(), PointF(), PointF()
    )

    init {
        // Initialize ML Kit Subject Segmenter
        val options = SubjectSegmenterOptions.Builder()
            .enableForegroundBitmap()
            .enableForegroundConfidenceMask()
            .build()
        subjectSegmenter = SubjectSegmentation.getClient(options)
    }

    fun setImageUri(uri: Uri) {
        try {
            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
                inDither = false
                inPreferQualityOverSpeed = true
            }

            val inputStream = context.contentResolver.openInputStream(uri)
            originalBitmap = BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            currentBitmap = originalBitmap?.copy(Bitmap.Config.ARGB_8888, true)
            needsReprocessing = true
            calculateImageRect()
            resetCropRect()
            invalidate()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setCropMode(enabled: Boolean) {
        isCropMode = enabled
        if (enabled) {
            resetCropRect()
        }
        invalidate()
    }

    private fun resetCropRect() {
        if (imageRect.isEmpty) return

        val margin = 10f

        cropRect.set(
            imageRect.left + margin,
            imageRect.top + margin,
            imageRect.right - margin,
            imageRect.bottom - margin
        )
        updateHandles()
    }

    private fun updateHandles() {
        // Corner handles
        handles[0].set(cropRect.left, cropRect.top)           // TL
        handles[1].set(cropRect.right, cropRect.top)          // TR
        handles[2].set(cropRect.left, cropRect.bottom)        // BL
        handles[3].set(cropRect.right, cropRect.bottom)       // BR
        handles[4].set(cropRect.centerX(), cropRect.centerY()) // Center

        // Edge handles
        handles[5].set(cropRect.centerX(), cropRect.top)      // Top
        handles[6].set(cropRect.right, cropRect.centerY())    // Right
        handles[7].set(cropRect.centerX(), cropRect.bottom)   // Bottom
        handles[8].set(cropRect.left, cropRect.centerY())     // Left
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        calculateImageRect()
    }

    private fun calculateImageRect() {
        originalBitmap?.let { bitmap ->
            if (width <= 0 || height <= 0) {
                // If view hasn't been measured yet, post to calculate later
                post { calculateImageRect() }
                return
            }

            val viewAspect = width.toFloat() / height.toFloat()
            val bitmapAspect = bitmap.width.toFloat() / bitmap.height.toFloat()

            if (bitmapAspect > viewAspect) {
                // Fit width
                val scaledHeight = width / bitmapAspect
                val top = (height - scaledHeight) / 2
                imageRect.set(0f, top, width.toFloat(), top + scaledHeight)
            } else {
                // Fit height
                val scaledWidth = height * bitmapAspect
                val left = (width - scaledWidth) / 2
                imageRect.set(left, 0f, left + scaledWidth, height.toFloat())
            }

            // Store original image rect for accurate calculations
            originalImageRect.set(imageRect)
            resetCropRect()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        displayBitmap = getCurrentDisplayBitmap()

        displayBitmap?.let { bitmap ->
            if (!bitmap.isRecycled) {
                // Update image rect based on current bitmap dimensions
                updateImageRectForCurrentBitmap(bitmap)

                val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
                val dstRect = Rect(
                    imageRect.left.toInt(),
                    imageRect.top.toInt(),
                    imageRect.right.toInt(),
                    imageRect.bottom.toInt()
                )
                canvas.drawBitmap(bitmap, srcRect, dstRect, paint)
            }
        }

        if (isCropMode && !cropRect.isEmpty) {
            drawCropOverlay(canvas)
        }
    }

    private fun updateImageRectForCurrentBitmap(bitmap: Bitmap) {
        val viewAspect = width.toFloat() / height.toFloat()
        val bitmapAspect = bitmap.width.toFloat() / bitmap.height.toFloat()

        if (bitmapAspect > viewAspect) {
            // Fit width
            val scaledHeight = width / bitmapAspect
            val top = (height - scaledHeight) / 2
            imageRect.set(0f, top, width.toFloat(), top + scaledHeight)
        } else {
            // Fit height
            val scaledWidth = height * bitmapAspect
            val left = (width - scaledWidth) / 2
            imageRect.set(left, 0f, left + scaledWidth, height.toFloat())
        }
    }

    private fun getCurrentDisplayBitmap(): Bitmap? {
        return currentBitmap?.let { bitmap ->
            if (needsReprocessing ||
                rotationAngle != lastRotationAngle ||
                filterIndex != lastFilterIndex) {

                val oldBitmap = cachedProcessedBitmap
                cachedProcessedBitmap = processImage(bitmap)

                if (oldBitmap != null &&
                    oldBitmap != bitmap &&
                    oldBitmap != originalBitmap &&
                    oldBitmap != currentBitmap &&
                    !oldBitmap.isRecycled) {
                    oldBitmap.recycle()
                }

                lastRotationAngle = rotationAngle
                lastFilterIndex = filterIndex
                needsReprocessing = false
            }

            cachedProcessedBitmap ?: bitmap
        }
    }

    private fun processImage(sourceBitmap: Bitmap): Bitmap {
        if (rotationAngle == 0f && filterIndex == 0) {
            return sourceBitmap
        }

        var result = sourceBitmap

        // Apply rotation if needed
        if (rotationAngle != 0f) {
            val rotated = rotateImageHighQuality(result, rotationAngle)
            if (rotated != result) {
                result = rotated
            }
        }

        // Apply filter if needed
        if (filterIndex != 0) {
            val filtered = applyCurrentFilter(result)
            if (filtered != result) {
                result = filtered
            }
        }

        return result
    }

    private fun rotateImageHighQuality(bitmap: Bitmap, angle: Float): Bitmap {
        if (angle == 0f || bitmap.isRecycled) return bitmap

        val matrix = Matrix().apply {
            postRotate(angle)
        }

        return try {
            Bitmap.createBitmap(
                bitmap, 0, 0,
                bitmap.width, bitmap.height,
                matrix, true
            )
        } catch (e: Exception) {
            e.printStackTrace()
            bitmap
        }
    }

    private fun applyCurrentFilter(bitmap: Bitmap): Bitmap {
        if (filterIndex == 0 || bitmap.isRecycled) return bitmap

        return try {
            val filteredBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(filteredBitmap)
            val filterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                isFilterBitmap = true
                isDither = false
            }

            when (filterIndex) {
                1 -> {
                    // Grayscale
                    val colorMatrix = ColorMatrix().apply { setSaturation(0f) }
                    filterPaint.colorFilter = ColorMatrixColorFilter(colorMatrix)
                }
                2 -> {
                    // Sepia
                    val sepiaMatrix = ColorMatrix(floatArrayOf(
                        0.393f, 0.769f, 0.189f, 0f, 0f,
                        0.349f, 0.686f, 0.168f, 0f, 0f,
                        0.272f, 0.534f, 0.131f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    ))
                    filterPaint.colorFilter = ColorMatrixColorFilter(sepiaMatrix)
                }
                3 -> {
                    // High contrast
                    val contrastMatrix = ColorMatrix(floatArrayOf(
                        2f, 0f, 0f, 0f, -128f,
                        0f, 2f, 0f, 0f, -128f,
                        0f, 0f, 2f, 0f, -128f,
                        0f, 0f, 0f, 1f, 0f
                    ))
                    filterPaint.colorFilter = ColorMatrixColorFilter(contrastMatrix)
                }
            }

            canvas.drawBitmap(bitmap, 0f, 0f, filterPaint)
            filteredBitmap
        } catch (e: Exception) {
            e.printStackTrace()
            bitmap
        }
    }

    private fun drawCropOverlay(canvas: Canvas) {
        // Draw overlay outside crop area
        canvas.drawRect(imageRect.left, imageRect.top, imageRect.right, cropRect.top, overlayPaint)
        canvas.drawRect(imageRect.left, cropRect.bottom, imageRect.right, imageRect.bottom, overlayPaint)
        canvas.drawRect(imageRect.left, cropRect.top, cropRect.left, cropRect.bottom, overlayPaint)
        canvas.drawRect(cropRect.right, cropRect.top, imageRect.right, cropRect.bottom, overlayPaint)

        // Draw crop rectangle border
        canvas.drawRect(cropRect, cropPaint)

        // Draw grid lines
//        val gridPaint = Paint(cropPaint).apply {
//            alpha = 100
//            strokeWidth = 1f
//        }
//        val third1X = cropRect.left + cropRect.width() / 3
//        val third2X = cropRect.left + 2 * cropRect.width() / 3
//        val third1Y = cropRect.top + cropRect.height() / 3
//        val third2Y = cropRect.top + 2 * cropRect.height() / 3

//        canvas.drawLine(third1X, cropRect.top, third1X, cropRect.bottom, gridPaint)
//        canvas.drawLine(third2X, cropRect.top, third2X, cropRect.bottom, gridPaint)
//        canvas.drawLine(cropRect.left, third1Y, cropRect.right, third1Y, gridPaint)
//        canvas.drawLine(cropRect.left, third2Y, cropRect.right, third2Y, gridPaint)

        // Draw corner handles (circular)
        for (i in 0..3) {
            canvas.drawCircle(handles[i].x, handles[i].y, cornerRadius, cornerPaint)
            canvas.drawCircle(handles[i].x, handles[i].y, cornerRadius, cornerStrokePaint)
        }

        // Draw edge handles (small rectangles)
        for (i in 5..8) {
            when (i) {
                5, 7 -> { // Top and bottom handles (horizontal)
                    canvas.drawRect(
                        handles[i].x - edgeHandleSize * 2,
                        handles[i].y - edgeHandleSize,
                        handles[i].x + edgeHandleSize * 2,
                        handles[i].y + edgeHandleSize,
                        edgeHandlePaint
                    )
                    canvas.drawRect(
                        handles[i].x - edgeHandleSize * 2,
                        handles[i].y - edgeHandleSize,
                        handles[i].x + edgeHandleSize * 2,
                        handles[i].y + edgeHandleSize,
                        edgeHandleStrokePaint
                    )
                }
                6, 8 -> { // Right and left handles (vertical)
                    canvas.drawRect(
                        handles[i].x - edgeHandleSize,
                        handles[i].y - edgeHandleSize * 2,
                        handles[i].x + edgeHandleSize,
                        handles[i].y + edgeHandleSize * 2,
                        edgeHandlePaint
                    )
                    canvas.drawRect(
                        handles[i].x - edgeHandleSize,
                        handles[i].y - edgeHandleSize * 2,
                        handles[i].x + edgeHandleSize,
                        handles[i].y + edgeHandleSize * 2,
                        edgeHandleStrokePaint
                    )
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isCropMode) return false

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y

                dragHandle = -1

                // Check corner handles first
                for (i in 0..3) {
                    if (isPointInCircleHandle(event.x, event.y, handles[i], cornerRadius)) {
                        dragHandle = i
                        isResizing = true
                        // Disable ViewPager touch when touching crop handles
                        parent?.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }

                // Check edge handles
                for (i in 5..8) {
                    if (isPointInEdgeHandle(event.x, event.y, handles[i], i)) {
                        dragHandle = i
                        isResizing = true
                        // Disable ViewPager touch when touching crop handles
                        parent?.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }

                // Check if inside crop area for dragging
                if (cropRect.contains(event.x, event.y)) {
                    dragHandle = 4
                    isDragging = true
                    // Disable ViewPager touch when touching crop area
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }

            MotionEvent.ACTION_MOVE -> {
                val deltaX = event.x - lastTouchX
                val deltaY = event.y - lastTouchY

                when {
                    isResizing && dragHandle in 0..3 -> {
                        resizeCropRect(dragHandle, event.x, event.y)
                        invalidate()
                    }
                    isResizing && dragHandle in 5..8 -> {
                        resizeCropRectEdge(dragHandle, event.x, event.y)
                        invalidate()
                    }
                    isDragging && dragHandle == 4 -> {
                        moveCropRect(deltaX, deltaY)
                        invalidate()
                    }
                }

                lastTouchX = event.x
                lastTouchY = event.y
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDragging = false
                isResizing = false
                dragHandle = -1
                // Re-enable ViewPager touch when crop interaction ends
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }

        return true
    }

    private fun isPointInCircleHandle(x: Float, y: Float, handle: PointF, radius: Float): Boolean {
        val distance = sqrt((x - handle.x).pow(2) + (y - handle.y).pow(2))
        return distance <= radius + touchTolerance
    }

    private fun isPointInEdgeHandle(x: Float, y: Float, handle: PointF, handleIndex: Int): Boolean {
        return when (handleIndex) {
            5, 7 -> { // Top and bottom handles (horizontal)
                abs(x - handle.x) <= edgeHandleSize * 2 + touchTolerance &&
                        abs(y - handle.y) <= edgeHandleSize + touchTolerance
            }
            6, 8 -> { // Right and left handles (vertical)
                abs(x - handle.x) <= edgeHandleSize + touchTolerance &&
                        abs(y - handle.y) <= edgeHandleSize * 2 + touchTolerance
            }
            else -> false
        }
    }

    private fun resizeCropRect(handleIndex: Int, x: Float, y: Float) {
        val newRect = RectF(cropRect)

        when (handleIndex) {
            0 -> {
                newRect.left = x.coerceIn(imageRect.left, cropRect.right - 50f)
                newRect.top = y.coerceIn(imageRect.top, cropRect.bottom - 50f)
            }
            1 -> {
                newRect.right = x.coerceIn(cropRect.left + 50f, imageRect.right)
                newRect.top = y.coerceIn(imageRect.top, cropRect.bottom - 50f)
            }
            2 -> {
                newRect.left = x.coerceIn(imageRect.left, cropRect.right - 50f)
                newRect.bottom = y.coerceIn(cropRect.top + 50f, imageRect.bottom)
            }
            3 -> {
                newRect.right = x.coerceIn(cropRect.left + 50f, imageRect.right)
                newRect.bottom = y.coerceIn(cropRect.top + 50f, imageRect.bottom)
            }
        }

        cropRect = newRect
        updateHandles()
    }

    private fun resizeCropRectEdge(handleIndex: Int, x: Float, y: Float) {
        val newRect = RectF(cropRect)

        when (handleIndex) {
            5 -> { // Top edge
                newRect.top = y.coerceIn(imageRect.top, cropRect.bottom - 50f)
            }
            6 -> { // Right edge
                newRect.right = x.coerceIn(cropRect.left + 50f, imageRect.right)
            }
            7 -> { // Bottom edge
                newRect.bottom = y.coerceIn(cropRect.top + 50f, imageRect.bottom)
            }
            8 -> { // Left edge
                newRect.left = x.coerceIn(imageRect.left, cropRect.right - 50f)
            }
        }

        cropRect = newRect
        updateHandles()
    }

    private fun moveCropRect(deltaX: Float, deltaY: Float) {
        val newRect = RectF(cropRect)
        newRect.offset(deltaX, deltaY)

        if (newRect.left < imageRect.left) {
            newRect.offset(imageRect.left - newRect.left, 0f)
        }
        if (newRect.right > imageRect.right) {
            newRect.offset(imageRect.right - newRect.right, 0f)
        }
        if (newRect.top < imageRect.top) {
            newRect.offset(0f, imageRect.top - newRect.top)
        }
        if (newRect.bottom > imageRect.bottom) {
            newRect.offset(0f, imageRect.bottom - newRect.bottom)
        }

        cropRect = newRect
        updateHandles()
    }

    fun rotateImage() {
        rotationAngle = (rotationAngle + 90f) % 360f
        needsReprocessing = true
        invalidate()
    }

    fun applyFilter(currentFilterIndex: Int) {
        filterIndex = currentFilterIndex
        needsReprocessing = true
        invalidate()
    }

    // ML Kit Auto Crop Subject Function
    fun autoSegmentSubject(callback: (Bitmap?) -> Unit) {
        val bitmap = originalBitmap ?: run {
            callback(null)
            return
        }

        val image = InputImage.fromBitmap(bitmap, 0)
        subjectSegmenter?.process(image)
            ?.addOnSuccessListener { result: SubjectSegmentationResult ->
                val foregroundBitmap = result.foregroundBitmap
                callback(foregroundBitmap)
            }
            ?.addOnFailureListener { e ->
                e.printStackTrace()
                callback(null)
            }
    }

    // Improved getCroppedBitmap method
    fun getCroppedBitmap(): Bitmap? {
        val sourceBitmap = originalBitmap ?: return null

        if (!isCropMode || cropRect.isEmpty) {
            return getCurrentDisplayBitmap()
        }

        return try {
            // Start with original bitmap
            var workingBitmap = sourceBitmap

            // Apply rotation if needed
            if (rotationAngle != 0f) {
                val rotatedBitmap = rotateImageHighQuality(sourceBitmap, rotationAngle)
                if (rotatedBitmap != sourceBitmap) {
                    workingBitmap = rotatedBitmap
                }
            }

            // Calculate the correct scale factors
            // Use original image rect for accurate calculation
            val scaleX = workingBitmap.width.toFloat() / originalImageRect.width()
            val scaleY = workingBitmap.height.toFloat() / originalImageRect.height()

            // Calculate crop coordinates
            val cropX = ((cropRect.left - originalImageRect.left) * scaleX).toInt().coerceAtLeast(0)
            val cropY = ((cropRect.top - originalImageRect.top) * scaleY).toInt().coerceAtLeast(0)
            val cropWidth = (cropRect.width() * scaleX).toInt().coerceAtMost(workingBitmap.width - cropX)
            val cropHeight = (cropRect.height() * scaleY).toInt().coerceAtMost(workingBitmap.height - cropY)

            // Validate dimensions
            if (cropWidth <= 0 || cropHeight <= 0) {
                return workingBitmap
            }

            // Create cropped bitmap
            val croppedBitmap = Bitmap.createBitmap(workingBitmap, cropX, cropY, cropWidth, cropHeight)

            // Apply filters if needed
            val finalBitmap = if (filterIndex != 0) {
                applyCurrentFilter(croppedBitmap)
            } else {
                croppedBitmap
            }

            // Clean up intermediate bitmaps
            if (workingBitmap != sourceBitmap && !workingBitmap.isRecycled) {
                workingBitmap.recycle()
            }
            if (finalBitmap != croppedBitmap && !croppedBitmap.isRecycled) {
                croppedBitmap.recycle()
            }

            finalBitmap

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // ML Kit enhanced cropping with subject detection
    fun getCroppedBitmapWithSubjectDetection(callback: (Bitmap?) -> Unit) {
        autoSegmentSubject { segmentedBitmap ->
            if (segmentedBitmap != null) {
                // Use the segmented bitmap as the source for cropping
                val croppedResult = cropBitmapWithRect(segmentedBitmap, cropRect)
                callback(croppedResult)
            } else {
                // Fall back to regular cropping
                callback(getCroppedBitmap())
            }
        }
    }

    private fun cropBitmapWithRect(bitmap: Bitmap, rect: RectF): Bitmap? {
        return try {
            val scaleX = bitmap.width.toFloat() / imageRect.width()
            val scaleY = bitmap.height.toFloat() / imageRect.height()

            val cropX = ((rect.left - imageRect.left) * scaleX).toInt().coerceAtLeast(0)
            val cropY = ((rect.top - imageRect.top) * scaleY).toInt().coerceAtLeast(0)
            val cropWidth = (rect.width() * scaleX).toInt().coerceAtMost(bitmap.width - cropX)
            val cropHeight = (rect.height() * scaleY).toInt().coerceAtMost(bitmap.width - cropY)

            if (cropWidth > 0 && cropHeight > 0) {
                Bitmap.createBitmap(bitmap, cropX, cropY, cropWidth, cropHeight)
            } else {
                bitmap
            }
        } catch (e: Exception) {
            e.printStackTrace()
            bitmap
        }
    }

    fun getCurrentBitmap(): Bitmap? {
        return getCurrentDisplayBitmap()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        cleanup()
    }

    fun cleanup() {
        // Clean up ML Kit resources
        subjectSegmenter?.close()
        subjectSegmenter = null

        // Clean up cached bitmaps
        if (cachedProcessedBitmap != null &&
            cachedProcessedBitmap != originalBitmap &&
            cachedProcessedBitmap != currentBitmap &&
            !cachedProcessedBitmap!!.isRecycled) {
            cachedProcessedBitmap?.recycle()
        }
        cachedProcessedBitmap = null
        needsReprocessing = true
    }
}