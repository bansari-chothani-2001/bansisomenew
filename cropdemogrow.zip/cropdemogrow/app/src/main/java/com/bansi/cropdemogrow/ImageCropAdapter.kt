package com.bansi.cropdemogrow

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class ImageCropAdapter(
    private val context: Context,
    private val imageUris: MutableList<Uri>
) : RecyclerView.Adapter<ImageCropAdapter.CropViewHolder>() {

    private val cropViews = mutableMapOf<Int, CustomCropOverlayView>()
    private var isCropMode = false

    inner class CropViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cropView: CustomCropOverlayView = itemView.findViewById(R.id.crop_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CropViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_crop_page, parent, false)
        return CropViewHolder(view)
    }

    override fun onBindViewHolder(holder: CropViewHolder, position: Int) {
        val uri = imageUris[position]
        holder.cropView.setImageUri(uri)
        holder.cropView.setCropMode(isCropMode)

        // Store reference to crop view
        cropViews[position] = holder.cropView
    }

    override fun getItemCount(): Int = imageUris.size

    fun setCropMode(enabled: Boolean) {
        isCropMode = enabled
        cropViews.values.forEach { it.setCropMode(enabled) }
    }

    fun getCropViewAt(position: Int): CustomCropOverlayView? {
        return cropViews[position]
    }

    fun removeItem(position: Int) {
        if (position >= 0 && position < imageUris.size) {
            imageUris.removeAt(position)
            cropViews.remove(position)

            // Reindex crop views
            val newCropViews = mutableMapOf<Int, CustomCropOverlayView>()
            cropViews.forEach { (index, view) ->
                when {
                    index < position -> newCropViews[index] = view
                    index > position -> newCropViews[index - 1] = view
                }
            }
            cropViews.clear()
            cropViews.putAll(newCropViews)

            notifyItemRemoved(position)
            notifyItemRangeChanged(position, itemCount)
        }
    }

    // Method to refresh adapter with new saved image URIs
    fun refreshWithSavedFiles(savedFilePaths: List<String>) {
        // Clear existing data
        imageUris.clear()
        cropViews.clear()

        // Convert file paths to URIs and add to list
        savedFilePaths.forEach { filePath ->
            val file = File(filePath)
            if (file.exists()) {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider", // Make sure this matches your FileProvider authority
                    file
                )
                imageUris.add(uri)
            }
        }

        // Notify adapter of data change
        notifyDataSetChanged()
    }

    // Alternative method to add saved files to existing list
    fun addSavedFiles(savedFilePaths: List<String>) {
        val startPosition = imageUris.size

        savedFilePaths.forEach { filePath ->
            val file = File(filePath)
            if (file.exists()) {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                imageUris.add(uri)
            }
        }

        notifyItemRangeInserted(startPosition, savedFilePaths.size)
    }

    // Method to replace images with saved files (maintains same count)
    fun replaceBitmaps(savedFilePaths: List<String>) {
        if (savedFilePaths.size != imageUris.size) {
            // If count doesn't match, use refresh method
            refreshWithSavedFiles(savedFilePaths)
            return
        }

        // Replace URIs with saved file URIs
        for (i in savedFilePaths.indices) {
            val file = File(savedFilePaths[i])
            if (file.exists()) {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                imageUris[i] = uri
            }
        }

        // Clear crop views cache as URIs have changed
        cropViews.clear()

        // Notify adapter
        notifyDataSetChanged()
    }

    // Get current image URIs
    fun getCurrentImageUris(): List<Uri> {
        return imageUris.toList()
    }

    override fun onViewRecycled(holder: CropViewHolder) {
        super.onViewRecycled(holder)
        cropViews.remove(holder.adapterPosition)
    }

    fun replaceImageAt(position: Int, newUri: Uri) {
        if (position < imageUris.size) {
            imageUris[position] = newUri
            notifyItemChanged(position)
        }

    }
}