package com.bansi.cropdemogrow

import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2
import com.bansi.cropdemogrow.databinding.ActivityCropBinding
import java.io.File
import java.io.FileOutputStream

class CropActivity : AppCompatActivity() {

    private var binding: ActivityCropBinding? = null
    private var adapter: ImageCropAdapter? = null
    private var thumbnailAdapter: ThumbnailAdapter? = null

    private var imageUris = mutableListOf<Uri>()
    private var isCropMode = false
    private var currentPosition = 0
    private val filterNames = listOf("Original", "Grayscale", "Sepia", "High Contrast")

    // Gallery launcher
    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            replaceCurrentImage(uri)
        } else {
            Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
        }
    }
    private var originalBitmap: Bitmap? = null

    private var filterAdapter: FilterAdapter?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCropBinding.inflate(layoutInflater)
        val view = binding?.root
        setContentView(view)
        setupImageUris()
        setupViewPager()
        setupRecyclerView()
        setupClickListeners()
        setupViewPagerCallbacks()
        updateNavigationButtons()
        loadImage()
    }
    private fun loadImage() {
        // Load your original bitmap here
        // For example: originalBitmap = BitmapFactory.decodeResource(resources, R.drawable.your_image)
        originalBitmap = BitmapFactory.decodeResource(resources, R.drawable.wall1)
        originalBitmap?.let { bitmap ->
//            mainImageView.setImageBitmap(bitmap)
            generateFilterPreviews(bitmap)
        }
    }

    private fun generateFilterPreviews(originalBitmap: Bitmap) {
        // Create a smaller version for preview generation to improve performance
        val previewWidth = 150
        val previewHeight = (originalBitmap.height * previewWidth) / originalBitmap.width
        val smallBitmap = Bitmap.createScaledBitmap(originalBitmap, previewWidth, previewHeight, true)

        val filterItems = mutableListOf<FilterItem>()

        // Generate preview for each filter
        for (i in filterNames.indices) {
            val previewBitmap = applyFilterForPreview(smallBitmap, i)
            filterItems.add(FilterItem(i, filterNames[i], previewBitmap))
        }

        filterAdapter?.updateFilters(filterItems)
    }

    private fun applyFilterForPreview(bitmap: Bitmap, filterIndex: Int): Bitmap {
        if (filterIndex == 0 || bitmap.isRecycled) return bitmap.copy(Bitmap.Config.ARGB_8888, false)

        return try {
            val filteredBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(filteredBitmap)
            val filterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                isFilterBitmap = true
                isDither = false
            }

            when (filterIndex) {
                1 -> {
                    // Grayscale
                    val colorMatrix = ColorMatrix().apply { setSaturation(0f) }
                    filterPaint.colorFilter = ColorMatrixColorFilter(colorMatrix)
                }
                2 -> {
                    // Sepia
                    val sepiaMatrix = ColorMatrix(floatArrayOf(
                        0.393f, 0.769f, 0.189f, 0f, 0f,
                        0.349f, 0.686f, 0.168f, 0f, 0f,
                        0.272f, 0.534f, 0.131f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    ))
                    filterPaint.colorFilter = ColorMatrixColorFilter(sepiaMatrix)
                }
                3 -> {
                    // High contrast
                    val contrastMatrix = ColorMatrix(floatArrayOf(
                        2f, 0f, 0f, 0f, -128f,
                        0f, 2f, 0f, 0f, -128f,
                        0f, 0f, 2f, 0f, -128f,
                        0f, 0f, 0f, 1f, 0f
                    ))
                    filterPaint.colorFilter = ColorMatrixColorFilter(contrastMatrix)
                }
            }

            canvas.drawBitmap(bitmap, 0f, 0f, filterPaint)
            filteredBitmap
        } catch (e: Exception) {
            e.printStackTrace()
            bitmap.copy(Bitmap.Config.ARGB_8888, false)
        }
    }
    private fun setupImageUris() {
        val uriStrings = intent.getStringArrayListExtra("image_uris") ?: return
        imageUris = uriStrings.map { Uri.parse(it) }.toMutableList()
    }

    private fun setupViewPager() {
        adapter = ImageCropAdapter(this, imageUris)
        binding?.viewPager?.adapter = adapter
    }
    private var currentFilterIndex = 0

    private fun setupRecyclerView() {
        binding?.pageIndicator?.text = "1/${imageUris.size}"
        thumbnailAdapter = ThumbnailAdapter(this, imageUris) { position ->
            // Handle thumbnail click - prevent infinite loops
            if (binding?.viewPager?.currentItem != position) {
                binding?.viewPager?.setCurrentItem(position, true)
            }
        }
        filterAdapter = FilterAdapter(emptyList()) { filterIndex ->
            currentFilterIndex = filterIndex
            applyFilterToAllImages(currentFilterIndex)
        }

        binding?.bottomview?.filterrecycler?.apply {
            adapter = filterAdapter
            layoutManager = LinearLayoutManager(this@CropActivity, LinearLayoutManager.HORIZONTAL, false)
            setHasFixedSize(true)
        }
        binding?.recyclerResult?.apply {
            layoutManager =
                LinearLayoutManager(this@CropActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = thumbnailAdapter
            setHasFixedSize(true) // Optimize RecyclerView performance
            setItemViewCacheSize(20) // Cache more views for smoother scrolling
        }

        // Set initial selection
        thumbnailAdapter?.setSelectedPosition(0)
    }

    private fun setupViewPagerCallbacks() {
        binding?.viewPager?.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                binding?.pageIndicator?.text = "${position + 1}/${imageUris.size}"

                if (currentPosition != position) {
                    currentPosition = position

                    // Update RecyclerView selection efficiently
                    thumbnailAdapter?.setSelectedPosition(position)

                    // Scroll RecyclerView to show selected item (only if needed)
                    val layoutManager =
                        binding?.recyclerResult?.layoutManager as? LinearLayoutManager
                    val firstVisible = layoutManager?.findFirstVisibleItemPosition() ?: 0
                    val lastVisible = layoutManager?.findLastVisibleItemPosition() ?: 0

                    if (position < firstVisible || position > lastVisible) {
                        binding?.recyclerResult?.smoothScrollToPosition(position)
                    }

                    // Update navigation buttons
                    updateNavigationButtons()
                }
            }

            override fun onPageScrollStateChanged(state: Int) {
                super.onPageScrollStateChanged(state)
                // Disable RecyclerView scroll updates during ViewPager dragging
                if (state == ViewPager2.SCROLL_STATE_DRAGGING) {
                    binding?.recyclerResult?.suppressLayout(true)
                } else if (state == ViewPager2.SCROLL_STATE_IDLE) {
                    binding?.recyclerResult?.suppressLayout(false)
                }
            }
        })
    }

    private fun setupClickListeners() {
        binding?.btnSave?.setOnClickListener { saveImages() }
        binding?.bottomview?.btnRotate?.setOnClickListener { rotateCurrentImage() }
        binding?.bottomview?.btnDelete?.setOnClickListener { deleteCurrentImage() }
        binding?.bottomview?.btnFilter?.setOnClickListener {
//            applyFilterToAllImages()
            BottomFilteriewUnable(true)

        }
        binding?.bottomview?.btnCrop?.setOnClickListener {
            BottomCropviewUnable(true)
            toggleCropMode()
        }
        binding?.bottomview?.btnCancel?.setOnClickListener {
            toggleCropMode()
            BottomCropviewUnable(false)
        }

        binding?.bottomview?.btnDone?.setOnClickListener {
            BottomCropviewUnable(false)
            saveImages()
        }
        binding?.bottomview?.btnfilCancel?.setOnClickListener {
            toggleCropMode()
            BottomFilteriewUnable(false)
        }

        binding?.bottomview?.btnfilDone?.setOnClickListener {
            BottomFilteriewUnable(false)
//            saveImages()
        }
        binding?.bottomview?.btnRotate?.setOnClickListener{

        }
        binding?.btnPrevious?.setOnClickListener { navigateToPrevious() }
        binding?.btnNext?.setOnClickListener { navigateToNext() }
        binding?.bottomview?.btnCapture?.setOnClickListener { chooseNewImageFromGallery() }
    }

    private fun chooseNewImageFromGallery() {
        try {
            // Launch gallery to pick an image
            pickImageLauncher.launch("image/*")
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error opening gallery: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun replaceCurrentImage(newUri: Uri) {
        try {
            // Replace the current image URI
            imageUris[currentPosition] = newUri

            // Update ViewPager adapter
            adapter?.replaceImageAt(currentPosition, newUri)

            // Update RecyclerView thumbnail
            thumbnailAdapter?.replaceImageAt(currentPosition, newUri)

            // Refresh the current view
            binding?.viewPager?.adapter?.notifyItemChanged(currentPosition)
            thumbnailAdapter?.notifyItemChanged(currentPosition)

            Toast.makeText(this, "Image replaced successfully", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error replacing image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveImages() {
        val savedFiles = mutableListOf<String>()
        val currentAdapter = adapter ?: return

        for (i in 0 until currentAdapter.itemCount) {
            val cropView = currentAdapter.getCropViewAt(i)
            cropView?.let { view ->
                val croppedBitmap = if (isCropMode) {
                    view.getCroppedBitmap()
                } else {
                    view.getCurrentBitmap()
                }

                croppedBitmap?.let { bitmap ->
                    val fileName = "cropped_image_${System.currentTimeMillis()}_$i.jpg"
                    val file = File(filesDir, fileName)

                    try {
                        FileOutputStream(file).use { out ->
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                        }
                        savedFiles.add(file.absolutePath)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        if (savedFiles.isNotEmpty()) {
            currentAdapter.replaceBitmaps(savedFiles)

            // Update RecyclerView as well
            thumbnailAdapter?.updateImageUris(imageUris)

            Toast.makeText(
                this,
                "Images saved and refreshed: ${savedFiles.size}",
                Toast.LENGTH_SHORT
            ).show()

            isCropMode = false
            currentAdapter.setCropMode(false)
        } else {
            Toast.makeText(this, "No images to save", Toast.LENGTH_SHORT).show()
        }
    }

    private fun rotateCurrentImage() {
        adapter?.getCropViewAt(currentPosition)?.rotateImage()

        // Update thumbnail efficiently - use a handler to avoid immediate update conflicts
        binding?.recyclerResult?.post {
            thumbnailAdapter?.notifyItemChanged(currentPosition)
        }
    }

    private fun deleteCurrentImage() {
        val currentAdapter = adapter ?: return

        if (imageUris.size > 1) {
            imageUris.removeAt(currentPosition)
            currentAdapter.removeItem(currentPosition)

            // Update RecyclerView efficiently
            thumbnailAdapter?.removeItem(currentPosition)

            if (currentPosition >= currentAdapter.itemCount && currentAdapter.itemCount > 0) {
                currentPosition = currentAdapter.itemCount - 1
                binding?.viewPager?.setCurrentItem(currentPosition, false)
                thumbnailAdapter?.setSelectedPosition(currentPosition)
            }

            // Update navigation buttons after deletion
            updateNavigationButtons()
        } else {
            Toast.makeText(this, "Cannot delete the last image", Toast.LENGTH_SHORT).show()
        }
    }

//    private fun applyFilterToCurrentImage() {
//        adapter?.getCropViewAt(currentPosition)?.applyFilter()
//
//        // Update thumbnail efficiently - use a handler to avoid immediate update conflicts
//        binding?.recyclerResult?.post {
//            thumbnailAdapter?.notifyItemChanged(currentPosition)
//        }
//
//
//    }

    private fun applyFilterToAllImages(currentFilterIndex: Int) {

        val itemCount = adapter?.itemCount ?: 0

        for (i in 0 until itemCount) {
            adapter?.getCropViewAt(i)?.applyFilter(currentFilterIndex)
        }

        // Update all thumbnails efficiently
        binding?.recyclerResult?.post {
            thumbnailAdapter?.notifyDataSetChanged()
        }
    }

    private fun BottomCropviewUnable(boolean: Boolean = false) {
        if (boolean) {
            binding?.bottomview?.maincropview?.visibility = View.VISIBLE
            binding?.bottomview?.bottomBar?.visibility = View.GONE
        } else {
            binding?.bottomview?.maincropview?.visibility = View.GONE
            binding?.bottomview?.bottomBar?.visibility = View.VISIBLE
        }

    }
    private fun BottomFilteriewUnable(boolean: Boolean = false) {
        if (boolean) {
            binding?.bottomview?.mainFilterview?.visibility = View.VISIBLE
            binding?.bottomview?.bottomBar?.visibility = View.GONE
        } else {
            binding?.bottomview?.mainFilterview?.visibility = View.GONE
            binding?.bottomview?.bottomBar?.visibility = View.VISIBLE
        }

    }

    private fun toggleCropMode() {
        isCropMode = !isCropMode
        val currentAdapter = adapter ?: return
        currentAdapter.setCropMode(isCropMode)
    }

    private fun navigateToPrevious() {
        if (currentPosition > 0) {
            binding?.viewPager?.setCurrentItem(currentPosition - 1, true)
        } else {
            Toast.makeText(this, "Already at first image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToNext() {
        val currentAdapter = adapter ?: return
        if (currentPosition < currentAdapter.itemCount - 1) {
            binding?.viewPager?.setCurrentItem(currentPosition + 1, true)
        } else {
            Toast.makeText(this, "Already at last image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateNavigationButtons() {
        val currentAdapter = adapter ?: return

        // Update Previous button state
        binding?.btnPrevious?.isEnabled = currentPosition > 0
        binding?.btnPrevious?.alpha = if (currentPosition > 0) 1.0f else 0.5f

        // Update Next button state
        binding?.btnNext?.isEnabled = currentPosition < currentAdapter.itemCount - 1
        binding?.btnNext?.alpha = if (currentPosition < currentAdapter.itemCount - 1) 1.0f else 0.5f

        // Optional: Change button colors based on state
        binding?.btnPrevious?.setColorFilter(
            if (currentPosition > 0) Color.parseColor("#FFFFFF") else Color.GRAY
        )

        binding?.btnNext?.setColorFilter(
            if (currentPosition < currentAdapter.itemCount - 1) Color.parseColor("#FFFFFF") else Color.GRAY
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        binding = null
        adapter = null
        thumbnailAdapter = null
    }
}