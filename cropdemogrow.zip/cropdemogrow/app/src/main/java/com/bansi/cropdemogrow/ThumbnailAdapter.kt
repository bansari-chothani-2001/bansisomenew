package com.bansi.cropdemogrow

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy

class ThumbnailAdapter(
    private val context: Context,
    private var imageUris: MutableList<Uri>,
    private val onItemClick: (Int) -> Unit
) : RecyclerView.Adapter<ThumbnailAdapter.ThumbnailViewHolder>() {

    private var selectedPosition = 0

    inner class ThumbnailViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.thumbnail_image)
        val borderView: View = itemView.findViewById(R.id.border_view)

        init {
            itemView.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION && position != selectedPosition) {
                    onItemClick(position)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ThumbnailViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_thumbnail, parent, false)
        return ThumbnailViewHolder(view)
    }

    override fun onBindViewHolder(holder: ThumbnailViewHolder, position: Int) {
        val uri = imageUris[position]

        // Load thumbnail image with optimized settings
        Glide.with(context)
            .load(uri)
            .centerCrop()
            .override(80, 80) // Fixed size for thumbnails
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .skipMemoryCache(false)
            .into(holder.imageView)

        // Set border based on selection
        updateBorder(holder, position == selectedPosition)
    }

    override fun getItemCount(): Int = imageUris.size

    fun setSelectedPosition(position: Int) {
        if (selectedPosition != position) {
            val previousPosition = selectedPosition
            selectedPosition = position

            // Only notify if positions are valid and different
            if (previousPosition >= 0 && previousPosition < imageUris.size) {
                notifyItemChanged(previousPosition)
            }
            if (selectedPosition >= 0 && selectedPosition < imageUris.size) {
                notifyItemChanged(selectedPosition)
            }
        }
    }

    fun updateImageUris(newUris: MutableList<Uri>) {
        imageUris = newUris
        notifyDataSetChanged()
    }

    fun removeItem(position: Int) {
        imageUris.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, imageUris.size)

        // Adjust selected position if necessary
        if (selectedPosition >= position && selectedPosition > 0) {
            selectedPosition--
        }
    }

    private fun updateBorder(holder: ThumbnailViewHolder, isSelected: Boolean) {
        if (isSelected) {
            // Create selected border
            val selectedBorder = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setStroke(4, Color.parseColor("#B52F38")) // Purple border
                cornerRadius = 8f
            }
            holder.borderView.background = selectedBorder
            holder.borderView.visibility = View.VISIBLE
        } else {
            // Create unselected border
            val unselectedBorder = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setStroke(2, Color.parseColor("#E0E0E0")) // Light gray border
                cornerRadius = 8f
            }
            holder.borderView.background = unselectedBorder
            holder.borderView.visibility = View.VISIBLE
        }
    }

    fun replaceImageAt(position: Int, newUri: Uri) {
        if (position < imageUris.size) {
            imageUris[position] = newUri
            notifyItemChanged(position)
        }
    }
}