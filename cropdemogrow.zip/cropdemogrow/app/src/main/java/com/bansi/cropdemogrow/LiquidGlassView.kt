package com.bansi.cropdemogrow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.*
import kotlin.random.Random

class LiquidGlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val liquidPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val liquidDrops = mutableListOf<LiquidDrop>()
    private val ripples = mutableListOf<Ripple>()

    private var animator: ValueAnimator? = null
    private var animationProgress = 0f

    init {
        setupPaints()
        startBackgroundAnimation()
    }

    private fun setupPaints() {
        // Glass effect paint
        glassPaint.apply {
            isAntiAlias = true
            style = Paint.Style.FILL
            color = Color.parseColor("#40FFFFFF") // Semi-transparent white
        }

        // Liquid animation paint
        liquidPaint.apply {
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        // Stroke paint for glass border
        strokePaint.apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.parseColor("#60FFFFFF")
        }

        // Blur effect paint
        blurPaint.apply {
            isAntiAlias = true
            maskFilter = BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Draw animated background gradient
        drawAnimatedBackground(canvas)

        // Draw glass cards
        drawGlassCards(canvas)

        // Draw liquid drops
        drawLiquidDrops(canvas)

        // Draw ripples
        drawRipples(canvas)
    }

    private fun drawAnimatedBackground(canvas: Canvas) {
        val gradient = RadialGradient(
            width * 0.3f + sin(animationProgress * 2) * 100f,
            height * 0.4f + cos(animationProgress * 1.5f) * 80f,
            width * 0.8f,
            intArrayOf(
                Color.parseColor("#667eea"),
                Color.parseColor("#764ba2"),
                Color.parseColor("#2d1b69")
            ),
            floatArrayOf(0f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )

        val backgroundPaint = Paint().apply {
            shader = gradient
        }

        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
    }

    private fun drawGlassCards(canvas: Canvas) {
        val centerX = width / 2f
        val centerY = height / 2f

        // Main glass card
        val cardWidth = width * 0.8f
        val cardHeight = height * 0.6f
        val cardLeft = centerX - cardWidth / 2
        val cardTop = centerY - cardHeight / 2
        val cornerRadius = 30f

        // Draw blur effect behind glass
        blurPaint.color = Color.parseColor("#30FFFFFF")
        val blurRect = RectF(cardLeft - 10, cardTop - 10, cardLeft + cardWidth + 10, cardTop + cardHeight + 10)
        canvas.drawRoundRect(blurRect, cornerRadius + 10, cornerRadius + 10, blurPaint)

        // Draw main glass card
        val cardRect = RectF(cardLeft, cardTop, cardLeft + cardWidth, cardTop + cardHeight)
        canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, glassPaint)
        canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, strokePaint)

        // Draw smaller glass elements
        drawSmallGlassElements(canvas, centerX, centerY)
    }

    private fun drawSmallGlassElements(canvas: Canvas, centerX: Float, centerY: Float) {
        // Top glass element
        val topElementWidth = width * 0.4f
        val topElementHeight = 80f
        val topElementLeft = centerX - topElementWidth / 2
        val topElementTop = centerY - height * 0.2f

        val topRect = RectF(topElementLeft, topElementTop, topElementLeft + topElementWidth, topElementTop + topElementHeight)
        canvas.drawRoundRect(topRect, 20f, 20f, glassPaint)
        canvas.drawRoundRect(topRect, 20f, 20f, strokePaint)

        // Bottom glass elements (like dock)
        val bottomY = centerY + height * 0.15f
        val elementWidth = 60f
        val elementHeight = 60f
        val spacing = 20f

        for (i in 0..3) {
            val x = centerX - (elementWidth * 2 + spacing * 1.5f) + i * (elementWidth + spacing)
            val elementRect = RectF(x, bottomY, x + elementWidth, bottomY + elementHeight)

            // Add slight animation offset
            val animOffset = sin(animationProgress + i * 0.5f) * 3f
            elementRect.offset(0f, animOffset)

            canvas.drawRoundRect(elementRect, 15f, 15f, glassPaint)
            canvas.drawRoundRect(elementRect, 15f, 15f, strokePaint)
        }
    }

    private fun drawLiquidDrops(canvas: Canvas) {
        liquidDrops.removeAll { it.alpha <= 0f }

        for (drop in liquidDrops) {
            drop.update()

            liquidPaint.color = Color.argb(
                (drop.alpha * 100).toInt(),
                drop.color.red,
                drop.color.green,
                drop.color.blue
            )

            // Create liquid blob shape
            val path = createLiquidPath(drop)
            canvas.drawPath(path, liquidPaint)
        }
    }

    private fun createLiquidPath(drop: LiquidDrop): Path {
        val path = Path()
        val points = 8
        val angleStep = 2 * PI / points

        for (i in 0 until points) {
            val angle = i * angleStep + drop.rotation
            val radiusVariation = 1f + sin(drop.wavePhase + i * 0.8f) * 0.3f
            val radius = drop.radius * radiusVariation

            val x = drop.x + cos(angle) * radius
            val y = drop.y + sin(angle) * radius

            if (i == 0) {
                path.moveTo(x.toFloat(), y.toFloat())
            } else {
                path.lineTo(x.toFloat(), y.toFloat())
            }
        }

        path.close()
        return path
    }

    private fun drawRipples(canvas: Canvas) {
        ripples.removeAll { it.alpha <= 0f }

        for (ripple in ripples) {
            ripple.update()

            strokePaint.apply {
                color = Color.argb((ripple.alpha * 80).toInt(), 255, 255, 255)
                strokeWidth = 3f - ripple.progress * 2f
            }

            canvas.drawCircle(ripple.x, ripple.y, ripple.radius, strokePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                createLiquidDrops(event.x, event.y)
                createRipple(event.x, event.y)
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun createLiquidDrops(x: Float, y: Float) {
        repeat(3) {
            val drop = LiquidDrop(
                x = (x + Random.nextFloat() * 40 - 20).toDouble(),
                y = (y + Random.nextFloat() * 40 - 20).toDouble(),
                radius = Random.nextFloat() * 30 + 20,
                color = getRandomLiquidColor(),
                velocityX = (Random.nextFloat() * 4 - 2).toDouble(),
                velocityY = (Random.nextFloat() * 4 - 2).toDouble()
            )
            liquidDrops.add(drop)
        }
    }

    private fun createRipple(x: Float, y: Float) {
        val ripple = Ripple(x, y)
        ripples.add(ripple)
    }

    private fun getRandomLiquidColor(): LiquidColor {
        val colors = listOf(
            LiquidColor(120, 219, 255), // Blue
            LiquidColor(255, 119, 198), // Pink
            LiquidColor(120, 255, 180), // Green
            LiquidColor(255, 180, 120), // Orange
            LiquidColor(180, 120, 255)  // Purple
        )
        return colors.random()
    }

    private fun startBackgroundAnimation() {
        animator = ValueAnimator.ofFloat(0f, 2 * PI.toFloat()).apply {
            duration = 20000
            repeatCount = ValueAnimator.INFINITE
            interpolator = DecelerateInterpolator()
            addUpdateListener { animation ->
                animationProgress = animation.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator?.cancel()
    }

    // Data classes for liquid effects
    data class LiquidColor(val red: Int, val green: Int, val blue: Int)

    data class LiquidDrop(
        var x: Double,
        var y: Double,
        var radius: Float,
        val color: LiquidColor,
        var velocityX: Double,
        var velocityY: Double,
        var alpha: Float = 1f,
        var rotation: Double = 0.0,
        var wavePhase: Double = 0.0
    ) {
        fun update() {
            x += velocityX
            y += velocityY
            alpha -= 0.008f
            rotation += 0.02
            wavePhase += 0.1

            // Fade and shrink
            radius *= 0.998f
            velocityX *= 0.98
            velocityY *= 0.98
        }
    }

    data class Ripple(
        val x: Float,
        val y: Float,
        var radius: Float = 10f,
        var alpha: Float = 1f,
        var progress: Float = 0f
    ) {
        fun update() {
            radius += 8f
            progress += 0.05f
            alpha = 1f - progress
        }
    }
}