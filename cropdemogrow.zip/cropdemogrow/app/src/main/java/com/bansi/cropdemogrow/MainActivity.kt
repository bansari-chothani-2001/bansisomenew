package com.bansi.cropdemogrow

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    
    private lateinit var selectImagesBtn: Button

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val intent = Intent(this, CropActivity::class.java)
            intent.putExtra("image_uris", ArrayList(uris.map { it.toString() }))
            startActivity(intent)
        } else {
            Toast.makeText(this, "No images selected", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        selectImagesBtn = findViewById(R.id.btn_select_images)
        selectImagesBtn.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }
    }
}