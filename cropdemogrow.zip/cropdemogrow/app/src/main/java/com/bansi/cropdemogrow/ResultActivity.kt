package com.bansi.cropdemogrow

import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ResultActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var btnDone: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        
        recyclerView = findViewById(R.id.recycler_result)
        btnDone = findViewById(R.id.btn_done)
        
        val savedFiles = intent.getStringArrayListExtra("saved_files") ?: emptyList()
        
        recyclerView.layoutManager = GridLayoutManager(this, 2)
        recyclerView.adapter = ResultAdapter(savedFiles)
        
        btnDone.setOnClickListener {
            finish()
        }
    }
}

class ResultAdapter(private val filePaths: List<String>) : 
    RecyclerView.Adapter<ResultAdapter.ResultViewHolder>() {
    
    inner class ResultViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val imageView: android.widget.ImageView = itemView.findViewById(R.id.img_result)
    }
    
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ResultViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_result, parent, false)
        return ResultViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ResultViewHolder, position: Int) {
        val bitmap = BitmapFactory.decodeFile(filePaths[position])
        holder.imageView.setImageBitmap(bitmap)
    }
    
    override fun getItemCount(): Int = filePaths.size
}