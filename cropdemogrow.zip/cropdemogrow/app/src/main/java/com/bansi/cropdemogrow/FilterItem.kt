package com.bansi.cropdemogrow

import android.graphics.Bitmap

data class FilterItem(
    val id: Int,
    val name: String,
    val previewBitmap: Bitmap? = null
)